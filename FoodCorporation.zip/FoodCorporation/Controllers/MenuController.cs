﻿using FoodCorporation.App_Code;
using FoodCorporation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
namespace FoodCorporation.Controllers
{
    public class MenuController : Controller
    {
        public ActionResult Add()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpPost]

        public ActionResult Add(MenuModel record)
        {
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"INSERT INTO foodMenu VALUES
                    (@itemName, @itemPrice)";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@itemName", record.itemName);
                    sqlCmd.Parameters.AddWithValue("@itemPrice", record.itemPrice);
                    sqlCmd.ExecuteNonQuery();
                }
                query = @"INSERT INTO foodAddHistory VALUES
                    (@addOrRemove, @addremoveDate, @itemName, @itemExpense)";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@addOrRemove", "Added");
                    sqlCmd.Parameters.AddWithValue("@addremoveDate", DateTime.Now);
                    sqlCmd.Parameters.AddWithValue("@itemName", record.itemName);
                    sqlCmd.Parameters.AddWithValue("@itemExpense", record.itemPrice);
                    sqlCmd.ExecuteNonQuery();
                    return RedirectToAction("Index");
                }
            }
        }


        public ActionResult Index()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            var list = new List<MenuModel>();
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"SELECT itemID, itemName, itemPrice FROM foodMenu";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        while (sqlDr.Read())
                        {
                            list.Add(new MenuModel
                            {
                                itemID = int.Parse(sqlDr["itemID"].ToString()),
                                itemName = sqlDr["itemName"].ToString(),
                                itemPrice = int.Parse(sqlDr["itemPrice"].ToString())
                            });
                        }
                    }

                }
            }
            return View(list);
        }

        public ActionResult Buy()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Buy(int? id, MenuModel record)
        {
            var stu = new StudentModel();
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"SELECT studentFirstName, studentLastName, studentFunds FROM studentProfile WHERE studentID = @studentID";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@studentID", record.buyerID);

                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        if (sqlDr.HasRows)
                        {
                            while (sqlDr.Read())
                            { 
                                stu.studentFN = sqlDr["studentFirstName"].ToString();
                                stu.studentLN = sqlDr["studentLastName"].ToString();
                                stu.studentFunds = int.Parse(sqlDr["studentFunds"].ToString());
                            }
                        }
                        else
                        {
                            ViewBag.Message = "<div class='alert alert-danger'>ID does not Exist</div>"; // displays error message if credentials are incorrect
                            return View();
                        }
                    }
                }

                query = @"SELECT itemName, itemPrice FROM foodMenu WHERE itemID = @itemID";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@itemID", id);
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        while (sqlDr.Read())
                        {
                            record.itemName = sqlDr["itemName"].ToString();
                            record.itemPrice = int.Parse(sqlDr["itemPrice"].ToString());
                        }
                    }
                }
                query = @"UPDATE studentProfile SET studentFunds = studentFunds - @itemPrice WHERE studentID = @buyerID";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@itemPrice", record.itemPrice);
                    sqlCmd.Parameters.AddWithValue("@buyerID", record.buyerID);
                    sqlCmd.ExecuteNonQuery();
                }
                query = @"INSERT INTO purchaseHistory VALUES (@itemBuy, @itemCost, @buyer)";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@itemBuy", record.itemName);
                    sqlCmd.Parameters.AddWithValue("@itemCost", record.itemPrice);
                    sqlCmd.Parameters.AddWithValue("@buyer", stu.studentFN + " " + stu.studentLN);
                    sqlCmd.ExecuteNonQuery();
                    return RedirectToAction("Index");
                }
            }
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }
            var record = new MenuModel();
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"SELECT itemName, itemPrice FROM foodMenu WHERE itemID = @itemID";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("itemID", id);
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        while (sqlDr.Read())
                        {
                            record.itemName = sqlDr["itemName"].ToString();
                            record.itemPrice = int.Parse(sqlDr["itemPrice"].ToString());
                        }
                    }

                }
                query = @"DELETE FROM foodMenu WHERE itemID=@itemID";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("itemID", id);
                    sqlCmd.ExecuteNonQuery();
                }
                query = @"INSERT INTO foodAddHistory VALUES
                    (@addOrRemove, @addremoveDate, @itemName, @itemExpense)";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@addOrRemove", "Removed");
                    sqlCmd.Parameters.AddWithValue("@addremoveDate", DateTime.Now);
                    sqlCmd.Parameters.AddWithValue("@itemName", record.itemName);
                    sqlCmd.Parameters.AddWithValue("@itemExpense", record.itemPrice);
                    sqlCmd.ExecuteNonQuery();
                    return RedirectToAction("Index");
                }
            }
        }
    }
}
