﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodCorporation.App_Code;
using FoodCorporation.Models;
using System.Data.SqlClient;

namespace FoodCorporation.Controllers
{
    public class AddHistoryController : Controller
    {
        // GET: AddHistory
        public ActionResult Index()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            var list = new List<AddHistoryModel>();
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"SELECT addOrRemove, addremoveDate, itemName, itemExpense FROM foodAddHistory";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        while (sqlDr.Read())
                        {
                            list.Add(new AddHistoryModel
                            {
                                addOrRemove = sqlDr["addOrRemove"].ToString(),
                                addOrRemoveDate = DateTime.Parse(sqlDr["addremoveDate"].ToString()),
                                itemName = sqlDr["itemName"].ToString(),
                                itemExpense = int.Parse(sqlDr["itemExpense"].ToString())
                            });
                        }
                    }

                }
            }
            return View(list);
        }
    }
}