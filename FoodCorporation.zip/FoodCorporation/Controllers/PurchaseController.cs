﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using FoodCorporation.Models;
using FoodCorporation.App_Code;

namespace FoodCorporation.Controllers
{
    public class PurchaseController : Controller
    {
        // GET: Purchase
        public ActionResult Index()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            var list = new List<PurchaseModel>();
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"SELECT buyID, itemBuy, itemCost, buyer FROM purchaseHistory";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        while(sqlDr.Read())
                        {
                            list.Add(new PurchaseModel
                            {
                                buyID = int.Parse(sqlDr["buyID"].ToString()),
                                itemBuy = sqlDr["itemBuy"].ToString(),
                                itemCost = int.Parse(sqlDr["itemCost"].ToString()),
                                buyer = sqlDr["buyer"].ToString()
                                
                            }

                                );
                        }
                    }
                }
            }
                return View(list);
        }
    }
}