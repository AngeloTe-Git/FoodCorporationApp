﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodCorporation.App_Code;
using FoodCorporation.Models;
using System.Data.SqlClient;

namespace FoodCorporation.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(StaffModel record)
        {
            using (SqlConnection con = new SqlConnection(Helper.GetCon()))
            {
                con.Open();
                string query = @"SELECT staffID FROM staffProfiles
                    WHERE staffID=@staffID AND staffPassword=@staffPW";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@staffID", record.staffID);
                    cmd.Parameters.AddWithValue("@staffPW", record.staffPW);

                    using (SqlDataReader data = cmd.ExecuteReader())
                    {
                        if (data.HasRows)
                        {
                            while (data.Read())
                            {
                                Session["userid"] = data["staffID"].ToString();
                            }
                            return RedirectToAction("Index", "Home");
                        }
                        else
                        {
                            ViewBag.Message = "<div class='alert alert-danger'>Incorrect email or password.</div>"; // displays error message if credentials are incorrect
                            return View();
                        }
                    }
                }
            }
        }
    }
}