﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodCorporation.Models;
using FoodCorporation.App_Code;
using System.Data.SqlClient;

namespace FoodCorporation.Controllers
{
    public class StaffController : Controller
    {
        // GET: Staff

        public ActionResult Add()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpPost]
        public ActionResult Add(StaffModel record)
        {
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"INSERT INTO staffProfiles VALUES (@staffID, @staffLastName, @staffFirstName, @staffPassword)";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@staffID", record.staffID);
                    sqlCmd.Parameters.AddWithValue("@staffLastName", record.staffLN);
                    sqlCmd.Parameters.AddWithValue("@staffFirstName", record.staffFN);
                    sqlCmd.Parameters.AddWithValue("@staffPassword", record.staffPW);
                    sqlCmd.ExecuteNonQuery();
                    return RedirectToAction("Index");
                }
            }
        }
        public ActionResult Index()
        {
            if(Session["userid"]==null)
            {
                return RedirectToAction("Login", "Account");
            }
            var list = new List<StaffModel>();
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"SELECT staffID, staffLastName, staffFirstName FROM staffProfiles";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        while (sqlDr.Read())
                        {
                            list.Add(new StaffModel
                            {
                                staffID = sqlDr["staffID"].ToString(),
                                staffLN = sqlDr["staffLastName"].ToString(),
                                staffFN = sqlDr["staffFirstName"].ToString()
                            });
                        }
                    }
                }
            }
            return View(list);
        }
        public ActionResult Delete(int? id)
        {
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"DELETE FROM staffProfile WHERE staffID = @staffID";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@staffID", id);
                    sqlCmd.ExecuteNonQuery();
                    return RedirectToAction("Index");
                }
            }
        }
    }
}