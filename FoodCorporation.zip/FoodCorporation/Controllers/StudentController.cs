﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FoodCorporation.Models;
using FoodCorporation.App_Code;
using System.Data.SqlClient;

namespace FoodCorporation.Controllers
{
    public class StudentController : Controller
    {
        // GET: StudentProfile
        public ActionResult Add()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpPost]

        public ActionResult Add(StudentModel record)
        {
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"INSERT INTO studentProfile VALUES (@studentFirstName, @studentLastName, @studentFunds)";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@studentFirstName", record.studentFN);
                    sqlCmd.Parameters.AddWithValue("@studentLastName", record.studentLN);
                    sqlCmd.Parameters.AddWithValue("@studentFunds", record.studentFunds);
                    sqlCmd.ExecuteNonQuery();
                    return RedirectToAction("Index");

                }
            }
        }

        public ActionResult Index()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            var list = new List<StudentModel>();
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"SELECT studentID, studentFirstName, studentLastName, studentFunds FROM studentProfile";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                    {
                        while (sqlDr.Read())
                        {
                            list.Add(new StudentModel
                            {
                                studentID = int.Parse(sqlDr["studentID"].ToString()),
                                studentFN = sqlDr["studentFirstName"].ToString(),
                                studentLN = sqlDr["studentLastName"].ToString(),
                                studentFunds = int.Parse(sqlDr["studentFunds"].ToString())
                            });
                        }
                    }

                }

                return View(list);
            }
        }


       public ActionResult Fund()
        {
            if (Session["userid"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpPost]
        public ActionResult Fund(int? id, StudentModel record)
        {
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"UPDATE studentProfile SET studentFunds = studentFunds + @studentAddMoney WHERE studentID = @studentID";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@studentAddMoney", record.studentAddMoney);
                    sqlCmd.Parameters.AddWithValue("@studentID", id);
                    sqlCmd.ExecuteNonQuery();
                    return RedirectToAction("Index");
                }

            }
        }


        public ActionResult Delete(int? id)
        {
            using (SqlConnection sqlCon = new SqlConnection(Helper.GetCon()))
            {
                sqlCon.Open();
                string query = @"DELETE FROM studentProfile WHERE studentID = @studentID";
                using (SqlCommand sqlCmd = new SqlCommand(query, sqlCon))
                {
                    sqlCmd.Parameters.AddWithValue("@studentID", id);
                    sqlCmd.ExecuteNonQuery();
                    return RedirectToAction("Index");
                }
            }
        }
    }
}
