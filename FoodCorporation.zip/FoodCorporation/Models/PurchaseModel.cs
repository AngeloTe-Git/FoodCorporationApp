﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FoodCorporation.Models
{
    public class PurchaseModel
    {
        [Key]
        public int buyID { get; set; }

        [Display(Name ="Item Bought")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(20, ErrorMessage = "Invalid Input")]
        public string itemBuy { get; set; }

        [Display(Name ="Item Cost")]
        [Required(ErrorMessage = "Required")]
        [Range(00, 999999999999999999, ErrorMessage = "Invalid Price")]
        public int itemCost { get; set; }

        [Display(Name ="Purchaser")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(100, ErrorMessage = "Invalid Input")]
        public string buyer { get; set; }
    }
}