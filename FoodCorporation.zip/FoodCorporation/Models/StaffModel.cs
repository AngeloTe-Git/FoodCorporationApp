﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FoodCorporation.Models
{
    public class StaffModel
    {
        [Required(ErrorMessage = "Required")]
        [Display(Name = "ID")]
        [MaxLength(10, ErrorMessage = "Invalid Input")]
        public string staffID { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(50, ErrorMessage = "Invalid Input")]
        public string staffLN { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(50, ErrorMessage = "Invalid Input")]
        public string staffFN { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Required")]
        [DataType(DataType.Password)]
        [MaxLength(20, ErrorMessage = "Invalid Input")]
        public string staffPW { get; set; }
    }
}