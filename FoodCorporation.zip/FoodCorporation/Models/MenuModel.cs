﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FoodCorporation.Models
{
    public class MenuModel
    {
        [Key]
        [Display(Name = "Item No.")]
        public int itemID { get; set; }

        [Display(Name ="Buyer ID no.")]
        [Range(00, 999999999999999999, ErrorMessage = "Invalid ID")]
        public int buyerID { get; set; }

        [Display(Name = "Item Name")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(20, ErrorMessage = "Invalid Input")]
        public string itemName { get; set; }

        [Display(Name = "Item Price")]
        [Required(ErrorMessage = "Required")]
        [Range(00, 999999999999999999, ErrorMessage = "Invalid Price")]
        public int itemPrice { get; set; }
    }
}