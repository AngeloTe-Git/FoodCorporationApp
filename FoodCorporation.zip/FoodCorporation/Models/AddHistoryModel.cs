﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FoodCorporation.Models
{
    public class AddHistoryModel
    {
        [Key]
        [Display(Name = "History No.")]
        public int FoodItem { get; set; }

        [Display(Name = "Added/Removed")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(50, ErrorMessage = "Invalid Input")]
        public string addOrRemove { get; set; }

        [Display(Name = "Date Added/Removed")]
        [DisplayFormat(DataFormatString ="{0:MM-dd-yyyy HH:mm:ss}",ApplyFormatInEditMode =true)]
        [Required(ErrorMessage = "Required")]
        [DataType(DataType.DateTime)]
        public DateTime addOrRemoveDate { get; set; }

        [Display(Name = "Item Name")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(20, ErrorMessage = "Invalid Input")]
        public string itemName { get; set; }

        [Display(Name = "Item Price")]
        [Required(ErrorMessage = "Required")]
        [Range(00, 999999999999999999, ErrorMessage = "Invalid Price")]
        public int itemExpense { get; set; }
    }
}