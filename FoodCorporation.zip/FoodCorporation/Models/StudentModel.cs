﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace FoodCorporation.Models
{
    public class StudentModel
    {
        [Key]
        public int studentID { get; set; }

        [Display(Name = "Item List")]
        [Required(ErrorMessage = "Select from the list")]
        public int itemPrice { get; set; }

        public List<MenuModel> AllItems { get; set; }


        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(50, ErrorMessage = "Required")]
        public string studentFN { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Required")]
        [MaxLength(50, ErrorMessage = "Invalid Input")]
        public string studentLN { get; set; }

        [Display(Name = "Funds")]
        [Range(00, 999999999999999999, ErrorMessage = "Invalid Amount")]
        public int studentFunds { get; set; }

        [Display(Name = "Money to Add")]
        [Range(00, 999999999999999999, ErrorMessage = "Invalid Price")]
        public int studentAddMoney { get; set; }

    }
}